# -*- coding: utf-8 -*-
import os
import sys
import json
import zipfile
import shutil
import subprocess
import urllib.request
import urllib.error

sys.stdout.reconfigure(encoding='utf-8')

TOKEN = "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"
REPO = "mouhamadherzherz/stargate-cafe"
VERSION = "5.8.0"
TAG = f"v{VERSION}"
RELEASE_NAME = f"Stargate Cafe & Gaming System {TAG} AI PRO"

SOURCE_DIR = r"d:\STARGATE\stargate_cafe_source"
ORGANIZED_DIR = r"d:\STARGATE\organized_programs\cafe"
OUTPUT_ZIP = os.path.join(SOURCE_DIR, "Stargate_Cafe_Update.zip")

print("=== 1. Building Stargate_Cafe_Update.zip ===")
if os.path.exists(OUTPUT_ZIP):
    try:
        os.remove(OUTPUT_ZIP)
    except Exception:
        pass

# Files to include in zip
with zipfile.ZipFile(OUTPUT_ZIP, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root_file in os.listdir(ORGANIZED_DIR):
        abs_f = os.path.join(ORGANIZED_DIR, root_file)
        if os.path.isfile(abs_f):
            ext = os.path.splitext(root_file)[1].lower()
            if ext in ('.py', '.bat', '.json', '.txt', '.ico', '.png', '.jpg') and not root_file.endswith('.pyc'):
                if root_file not in ('cafe_accounting.db', 'lockfile', 'Stargate_Cafe_Update.zip', 'publish_release.py', 'publish_v570.py', 'publish_v580.py', 'republish_v532.py'):
                    zipf.write(abs_f, root_file)
    for sub in ['templates', 'static']:
        s_dir = os.path.join(ORGANIZED_DIR, sub)
        if os.path.exists(s_dir):
            for root, dirs, files in os.walk(s_dir):
                dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', 'logs')]
                for file in files:
                    if not file.endswith('.pyc') and not file.endswith('.tmp'):
                        abs_f = os.path.join(root, file)
                        rel_f = os.path.relpath(abs_f, ORGANIZED_DIR)
                        zipf.write(abs_f, rel_f)

zip_size_mb = os.path.getsize(OUTPUT_ZIP) / (1024 * 1024)
print(f"[OK] Stargate_Cafe_Update.zip built: {zip_size_mb:.2f} MB")

# Distribute zip locally
destinations = [
    r"d:\STARGATE\organized_programs\cafe\Stargate_Cafe_Update.zip",
    r"C:\STARGATE_CAFE\Stargate_Cafe_Update.zip",
    os.path.expanduser(r"~\Desktop\Stargate_Cafe_Update.zip")
]
for dst in destinations:
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(OUTPUT_ZIP, dst)
        print(f"[OK] Copied to: {dst}")
    except Exception as e:
        print(f"[!] Warning copying to {dst}: {e}")

print("\n=== 2. Committing and Pushing to GitHub (master) ===")
# Sync any updated files to source repo
for fname in ["accounting.py", "app.py", "database.py", "cafe_version.json", "desktop_app.py", "logger.py"]:
    shutil.copy2(os.path.join(ORGANIZED_DIR, fname), os.path.join(SOURCE_DIR, fname))

try:
    subprocess.run(["git", "-C", SOURCE_DIR, "add", "-A"], check=True)
    subprocess.run(["git", "-C", SOURCE_DIR, "commit", "-m", f"Release {TAG}: Automatic stock deduction, Telegram bot dispatcher, and AI smart auditor"], check=False)
    push_res = subprocess.run(["git", "-C", SOURCE_DIR, "push", f"https://{TOKEN}@github.com/{REPO}.git", "master"], capture_output=True, text=True)
    print("Push stdout:", push_res.stdout)
    print("Push stderr:", push_res.stderr)
    print("Push code:", push_res.returncode)
except Exception as e:
    print(f"Git push error: {e}")

print("\n=== 3. Creating / Updating GitHub Release v5.8.0 ===")
headers = {
    "Authorization": f"token {TOKEN}",
    "Accept": "application/vnd.github.v3+json",
    "User-Agent": "Stargate-Release-Bot"
}

with open(os.path.join(ORGANIZED_DIR, "cafe_version.json"), "r", encoding="utf-8") as vf:
    v_data = json.load(vf)

changelog_text = v_data.get("changelog", f"Release {TAG}")

# Check if release already exists
rel_api_url = f"https://api.github.com/repos/{REPO}/releases"
release_id = None
upload_url = None

try:
    check_req = urllib.request.Request(f"{rel_api_url}/tags/{TAG}", headers=headers)
    with urllib.request.urlopen(check_req) as resp:
        rel_info = json.loads(resp.read().decode('utf-8'))
        release_id = rel_info.get("id")
        upload_url = rel_info.get("upload_url", "").split("{")[0]
        print(f"[INFO] Existing release found (ID: {release_id})")
except urllib.error.HTTPError as e:
    if e.code == 404:
        print(f"[INFO] Release {TAG} does not exist yet. Creating...")
    else:
        print(f"[!] Warning checking release: {e}")

if not release_id:
    # Create release
    create_payload = json.dumps({
        "tag_name": TAG,
        "name": RELEASE_NAME,
        "body": changelog_text,
        "draft": False,
        "prerelease": False
    }).encode('utf-8')
    create_req = urllib.request.Request(rel_api_url, data=create_payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(create_req) as resp:
            rel_info = json.loads(resp.read().decode('utf-8'))
            release_id = rel_info.get("id")
            upload_url = rel_info.get("upload_url", "").split("{")[0]
            print(f"[OK] Release created successfully (ID: {release_id})")
    except Exception as e:
        print(f"[!] Error creating release: {e}")

if release_id and upload_url:
    # Delete existing asset if any
    try:
        assets_req = urllib.request.Request(f"{rel_api_url}/{release_id}/assets", headers=headers)
        with urllib.request.urlopen(assets_req) as resp:
            assets = json.loads(resp.read().decode('utf-8'))
            for a in assets:
                if a.get("name") == "Stargate_Cafe_Update.zip":
                    del_id = a.get("id")
                    del_req = urllib.request.Request(f"https://api.github.com/repos/{REPO}/releases/assets/{del_id}", headers=headers, method="DELETE")
                    urllib.request.urlopen(del_req)
                    print(f"[OK] Deleted old asset {del_id}")
    except Exception as e:
        print(f"[!] Note on checking old assets: {e}")

    # Upload Stargate_Cafe_Update.zip
    print("Uploading Stargate_Cafe_Update.zip to GitHub Release...")
    with open(OUTPUT_ZIP, 'rb') as f:
        zip_data = f.read()

    upload_asset_url = f"{upload_url}?name=Stargate_Cafe_Update.zip"
    up_headers = headers.copy()
    up_headers["Content-Type"] = "application/zip"
    up_headers["Content-Length"] = str(len(zip_data))

    up_req = urllib.request.Request(upload_asset_url, data=zip_data, headers=up_headers, method="POST")
    try:
        with urllib.request.urlopen(up_req) as resp:
            up_res = json.loads(resp.read().decode('utf-8'))
            print("[SUCCESS] Stargate_Cafe_Update.zip published to GitHub!")
            print("Download URL:", up_res.get("browser_download_url"))
    except Exception as e:
        print(f"[!] Error uploading asset: {e}")

# 4. Update Firebase Realtime Database
try:
    print("\n=== 4. Updating Firebase Realtime DB ===")
    fb_url = "https://stargate-experts-default-rtdb.firebaseio.com/cafe_updates/latest.json"
    fb_payload = json.dumps({
        "version": VERSION,
        "download_url": f"https://github.com/{REPO}/releases/download/{TAG}/Stargate_Cafe_Update.zip",
        "changelog": changelog_text,
        "release_date": "2026-10-11",
        "name": RELEASE_NAME
    }).encode('utf-8')
    fb_req = urllib.request.Request(fb_url, data=fb_payload, headers={'Content-Type': 'application/json'}, method="PUT")
    with urllib.request.urlopen(fb_req, timeout=10) as resp:
        print("[SUCCESS] Firebase Realtime DB updated to v5.8.0!")
except Exception as e:
    print(f"[!] Firebase update note: {e}")

print("\n=== All Tasks Completed Successfully! v5.8.0 Published ===")
