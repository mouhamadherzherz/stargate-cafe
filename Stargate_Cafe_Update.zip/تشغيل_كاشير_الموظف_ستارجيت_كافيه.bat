@echo off
chcp 65001 >nul
title STARGATE CAFE - تشغيل شاشة الكاشير والموظف
color 0b

echo ========================================================
echo        STARGATE CAFE & GAMING - شاشة الكاشير والموظف
echo ========================================================
echo.

set "LOCAL_URL=http://127.0.0.1:5000"
set "SERVER_URL=http://192.168.10.27:5000"

:: Check if server is running locally on 5000
powershell -Command "try { $r = Invoke-WebRequest -Uri '%LOCAL_URL%/api/check_update' -TimeoutSec 1 -UseBasicParsing; exit 0 } catch { exit 1 }" >nul 2>&1
if %errorlevel% equ 0 (
    set "TARGET_URL=%LOCAL_URL%"
) else (
    powershell -Command "try { $r = Invoke-WebRequest -Uri '%SERVER_URL%/api/check_update' -TimeoutSec 1 -UseBasicParsing; exit 0 } catch { exit 1 }" >nul 2>&1
    if %errorlevel% equ 0 (
        set "TARGET_URL=%SERVER_URL%"
    ) else (
        echo [!] السيرفر غير مشتغل حالياً، جاري تشغيله فوراً...
        if exist "C:\STARGATE_CAFE" (
            cd /d "C:\STARGATE_CAFE"
        ) else if exist "d:\STARGATE\organized_programs\cafe" (
            cd /d "d:\STARGATE\organized_programs\cafe"
        )
        start "" pythonw.exe app.py
        timeout /t 3 /nobreak >nul
        set "TARGET_URL=%LOCAL_URL%"
    )
)

echo [OK] الرابط النشط: %TARGET_URL%
echo.

:: Launch with dedicated profile to prevent ProcessSingleton lock collisions
set "EDGE_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"

set "PROFILE_DIR=%LOCALAPPDATA%\StargateCafeBrowserProfile"
if not exist "%PROFILE_DIR%" mkdir "%PROFILE_DIR%" >nul 2>&1
if exist "%PROFILE_DIR%\lockfile" del /F /Q "%PROFILE_DIR%\lockfile" >nul 2>&1

if defined EDGE_EXE (
    start "" "%EDGE_EXE%" --user-data-dir="%PROFILE_DIR%" --app="%TARGET_URL%/employee/login" --window-size=1360,880 --no-first-run
) else (
    start "" "%TARGET_URL%/employee/login"
)

echo [OK] تم فتح واجهة الكافيه بنجاح!
timeout /t 2 >nul
exit
