import sqlite3

db_paths = [
    'C:/STARGATE_CAFE/data/cafe_accounting.db',
    'd:/STARGATE/organized_programs/cafe/cafe_accounting.db',
    'd:/STARGATE/stargate_cafe_source/data/cafe_accounting.db'
]

for p in db_paths:
    try:
        conn = sqlite3.connect(p)
        c = conn.cursor()
        c.execute("""
            UPDATE cafe_items 
            SET track_stock = 1 
            WHERE (item_type IS NULL OR item_type != 'gaming') 
              AND (is_coffee_bean_linked IS NULL OR is_coffee_bean_linked = 0)
        """)
        conn.commit()
        print(f"Updated {p}: affected {c.rowcount} rows")
        conn.close()
    except Exception as e:
        print(f"Skipping {p}: {e}")
