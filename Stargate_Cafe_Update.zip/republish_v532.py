import os
import sys
import json
import zipfile
import shutil
import urllib.request as ur

sys.stdout.reconfigure(encoding='utf-8')

SOURCE_DIR = r'd:\STARGATE\stargate_cafe_source'
OUTPUT_ZIP = r'C:\STARGATE_CAFE\Stargate_Cafe_Update.zip'

print('1. Repackaging Stargate_Cafe_Update.zip...')
with zipfile.ZipFile(OUTPUT_ZIP, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root_file in os.listdir(SOURCE_DIR):
        abs_f = os.path.join(SOURCE_DIR, root_file)
        if os.path.isfile(abs_f):
            ext = os.path.splitext(root_file)[1].lower()
            if ext in ('.py', '.bat', '.json', '.txt', '.ico', '.png', '.jpg') and not root_file.endswith('.pyc'):
                if root_file not in ('cafe_accounting.db', 'lockfile', 'Stargate_Cafe_Update.zip', 'publish_release.py', 'build_and_publish_v532.py'):
                    zipf.write(abs_f, root_file)
    for sub in ['templates', 'static']:
        s_dir = os.path.join(SOURCE_DIR, sub)
        if os.path.exists(s_dir):
            for root, dirs, files in os.walk(s_dir):
                dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git')]
                for file in files:
                    if not file.endswith('.pyc'):
                        abs_f = os.path.join(root, file)
                        rel_f = os.path.relpath(abs_f, SOURCE_DIR)
                        zipf.write(abs_f, rel_f)

print(f'Zip created: {os.path.getsize(OUTPUT_ZIP) / (1024*1024):.2f} MB')
shutil.copy2(OUTPUT_ZIP, os.path.expanduser('~/Desktop/Stargate_Cafe_Update.zip'))
print('Copied to Desktop!')

# Push commit to github
os.chdir(SOURCE_DIR)
os.system('git add app.py templates/base.html')
os.system('git commit -m "Add manual ZIP update card and robust remote update triggers"')
token = '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'
repo = 'mouhamadherzherz/stargate-cafe'
os.system(f'git push https://{token}@github.com/{repo}.git master')

# Replace on GitHub release
tag = 'v5.3.2'
headers = {'Authorization': f'token {token}', 'User-Agent': 'Stargate', 'Accept': 'application/vnd.github+json'}
req = ur.Request(f'https://api.github.com/repos/{repo}/releases/tags/{tag}', headers=headers)
with ur.urlopen(req) as r:
    rel = json.loads(r.read())
upload_url = rel['upload_url'].split('{')[0]

for asset in rel.get('assets', []):
    if asset['name'] == 'Stargate_Cafe_Update.zip':
        ur.urlopen(ur.Request(asset['url'], headers=headers, method='DELETE'))
        print('Deleted old release asset')

up_headers = dict(headers)
up_headers['Content-Type'] = 'application/zip'
up_headers['Content-Length'] = str(os.path.getsize(OUTPUT_ZIP))
up_req = ur.Request(f'{upload_url}?name=Stargate_Cafe_Update.zip', data=open(OUTPUT_ZIP, 'rb').read(), headers=up_headers, method='POST')
with ur.urlopen(up_req) as r:
    print('Uploaded new release asset successfully!')
