# -*- coding: utf-8 -*-
import urllib.request
import json

fb_url = "https://stargate-experts-default-rtdb.firebaseio.com/cafe_updates/latest.json"
payload = {
    "version": "5.8.0",
    "download_url": "https://github.com/mouhamadherzherz/stargate-cafe/releases/download/v5.8.0/Stargate_Cafe_Update.zip",
    "changelog": "v5.8.0: خصم المخزون التلقائي الذكي 100%، دمج خبير الذكاء الاصطناعي لكشف الأخطاء وإرشاد الكاشير، وربط بوت التيليجرام لإرسال التقارير المالية اليومية.",
    "release_date": "2026-10-11",
    "name": "Stargate Cafe & Gaming System v5.8.0 AI PRO"
}

data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
req = urllib.request.Request(fb_url, data=data, headers={'Content-Type': 'application/json'}, method='PUT')
with urllib.request.urlopen(req, timeout=10) as resp:
    print("Firebase response:", resp.read().decode('utf-8'))
