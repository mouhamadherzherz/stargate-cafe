with open('templates/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. We want the AI banner to appear right below <div class="flex-1 flex flex-col p-2.5 lg:p-4 max-w-full space-y-3 pb-12">
banner_code = '''    <!-- 🤖 LIVE AI SMART ASSISTANT POS BANNER (المساعد والمدقق الذكي المباشر على شاشة الكاشير) -->
    <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border-2 border-indigo-500/70 rounded-3xl p-3 shadow-xl flex flex-col md:flex-row items-center justify-between gap-3 shrink-0">
        <div class="flex items-center gap-3 w-full md:w-auto">
            <div class="w-11 h-11 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-2xl font-black border border-indigo-500/50 animate-pulse shrink-0">
                🤖✨
            </div>
            <div class="min-w-0">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="text-xs sm:text-sm font-black text-white">الذكاء الاصطناعي والمساعد الرقابي (STARGATE AI)</span>
                    <span class="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/40 font-bold">100% بدون إنترنت (Offline AI)</span>
                    <span class="text-[9px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/40 font-mono font-bold">سلامة العمليات: {{ ai_audit.health_score if ai_audit else 100 }}%</span>
                </div>
                <div class="text-[11px] text-slate-300 truncate mt-0.5">
                    {% if ai_audit and ai_audit.issues %}
                    <span class="text-rose-400 font-bold">⚠️ تنبيه رقابي:</span> {{ ai_audit.issues[0].title }} - {{ ai_audit.issues[0].desc }}
                    {% elif ai_audit and ai_audit.insights %}
                    <span class="text-amber-300 font-bold">💡 رصد ذكي:</span> {{ ai_audit.insights[0].title }} - {{ ai_audit.insights[0].desc }}
                    {% else %}
                    <span class="text-emerald-400 font-bold">✓ كافة العمليات المالية وجرد المخزون في وضع مثالي ومطابق 100%.</span>
                    {% endif %}
                </div>
            </div>
        </div>
        <div class="flex items-center gap-2 shrink-0 self-end md:self-center">
            <button type="button" onclick="openAIAuditModal()" class="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-xs px-4 py-2 rounded-xl transition shadow-lg shadow-indigo-600/40 active:scale-95 flex items-center gap-1.5 cursor-pointer border border-indigo-400/30">
                <span>استشارة الذكاء الاصطناعي ↗</span>
            </button>
        </div>
    </div>
'''

# Remove old AI banner if present around line 242
old_banner_start = '    <!-- 🤖 LIVE AI SMART ASSISTANT POS BANNER'
if old_banner_start in text:
    p1 = text.find(old_banner_start)
    p2 = text.find('<!-- 2.8 PRO QUICK COMMAND BAR', p1)
    if p1 != -1 and p2 != -1:
        text = text[:p1] + text[p2:]
        print("Removed old banner position")

# Now insert banner right after <div class="flex-1 flex flex-col p-2.5 lg:p-4 max-w-full space-y-3 pb-12">
target_open = '<div class="flex-1 flex flex-col p-2.5 lg:p-4 max-w-full space-y-3 pb-12">\n'
if target_open in text:
    text = text.replace(target_open, target_open + banner_code + '\n', 1)
    print("Inserted banner at top of page")
else:
    print("Warning: target_open not found")

with open('templates/index.html', 'w', encoding='utf-8') as f:
    f.write(text)

print("Finished placing AI banner.")
