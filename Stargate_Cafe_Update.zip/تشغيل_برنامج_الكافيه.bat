@echo off
chcp 65001 >nul
title STARGATE CAFE v5.7.0 PRO - Master Server
color 0b

echo ========================================================
echo   ☕ ستارجيت كافيه - STARGATE CAFE v5.7.0 PRO
echo   الرابط المحلي (لجهازك):     http://127.0.0.1:5000
echo   رابط الموظف (على الشبكة):  http://192.168.10.27:5000
echo ========================================================
echo.

powershell -Command "try { $r = Invoke-WebRequest -Uri 'http://127.0.0.1:5000/api/check_update' -TimeoutSec 1 -UseBasicParsing; exit 0 } catch { exit 1 }" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] السيرفر يعمل بالفعل بنجاح 100%%!
) else (
    echo [*] جاري بدء تشغيل السيرفر...
    if exist "C:\STARGATE_CAFE" (
        cd /d "C:\STARGATE_CAFE"
    ) else if exist "d:\STARGATE\organized_programs\cafe" (
        cd /d "d:\STARGATE\organized_programs\cafe"
    )
    start "" pythonw.exe app.py
    timeout /t 2 /nobreak >nul
)

start http://127.0.0.1:5000/employee/login
timeout /t 2 >nul
exit
