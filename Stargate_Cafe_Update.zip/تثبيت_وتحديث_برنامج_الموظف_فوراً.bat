@echo off
chcp 65001 >nul
color 0B
title STARGATE CAFE - تثبيت وتحديث جهاز الموظف v5.7.0 PRO

echo ======================================================================
echo         STARGATE CAFE - تثبيت وتحديث جهاز الموظف (v5.7.0 PRO)
echo ======================================================================
echo.

set "CAFE_DIR=C:\STARGATE_CAFE"
if not exist "%CAFE_DIR%" mkdir "%CAFE_DIR%" >nul 2>&1

:: 1. إيقاف أي عمليات سابقة
echo [1/4] إيقاف البرنامج القديم وفك قفل الملفات...
taskkill /F /IM STARGATE.exe >nul 2>&1
taskkill /F /IM python.exe /T >nul 2>&1
taskkill /F /IM pythonw.exe /T >nul 2>&1
ping 127.0.0.1 -n 2 >nul

:: 2. تنزيل حزمة التحديث v5.7.0
echo [2/4] جاري تنزيل أحدث نسخة v5.7.0...
set "TEMP_ZIP=%CAFE_DIR%\update_v570.zip"
set "TEMP_DIR=%CAFE_DIR%\update_v570_extracted"

if exist "%TEMP_DIR%" rmdir /S /Q "%TEMP_DIR%" >nul 2>&1
mkdir "%TEMP_DIR%" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; ^
   $downloaded = $false; ^
   try { ^
     Write-Host 'Downloading from local master server (http://192.168.10.27:5000)...'; ^
     $wc = New-Object System.Net.WebClient; ^
     $wc.DownloadFile('http://192.168.10.27:5000/download/update.zip', '%TEMP_ZIP%'); ^
     if (Test-Path '%TEMP_ZIP%') { $downloaded = $true } ^
   } catch { ^
     Write-Host 'Local server unreachable. Downloading from GitHub cloud...'; ^
   }; ^
   if (-not $downloaded) { ^
     try { ^
       $wc = New-Object System.Net.WebClient; ^
       $wc.DownloadFile('https://github.com/mouhamadherzherz/stargate-cafe/releases/download/v5.7.0/Stargate_Cafe_Update.zip', '%TEMP_ZIP%'); ^
     } catch { ^
       Write-Host 'Cloud download error:' $_.Exception.Message; ^
     } ^
   }; ^
   if (Test-Path '%TEMP_ZIP%') { ^
     Expand-Archive -Path '%TEMP_ZIP%' -DestinationPath '%TEMP_DIR%' -Force; ^
   }"

if not exist "%TEMP_DIR%\app.py" (
    echo.
    color 0C
    echo [!] فشل تنزيل التحديث. يرجى التأكد من اتصال الإنترنت أو اتصال الشبكة بالخادم الرئيسي.
    pause
    exit /b 1
)

:: 3. تثبيت التحديث مع حماية البيانات
echo [3/4] تثبيت التحديث وحماية قواعد البيانات...
robocopy "%TEMP_DIR%" "%CAFE_DIR%" /E /IS /IT /XF "*.db" "*.sqlite" "cafe_accounting.db" /XD "data" "Safe_Backups" >nul
if exist "%CAFE_DIR%\_internal" (
    robocopy "%TEMP_DIR%\templates" "%CAFE_DIR%\_internal\templates" /E /IS >nul 2>&1
    robocopy "%TEMP_DIR%\static"    "%CAFE_DIR%\_internal\static"    /E /IS >nul 2>&1
    copy /Y "%TEMP_DIR%\*.py" "%CAFE_DIR%\_internal\" >nul 2>&1
    copy /Y "%TEMP_DIR%\cafe_version.json" "%CAFE_DIR%\_internal\" >nul 2>&1
)

:: تنظيف الملفات المؤقتة
del /F /Q "%TEMP_ZIP%" >nul 2>&1
rmdir /S /Q "%TEMP_DIR%" >nul 2>&1

:: تنظيف كاش المتصفح لظهور الميزات فوراً
set "PROFILE_DIR=%LOCALAPPDATA%\StargateCafeBrowserProfile"
if exist "%PROFILE_DIR%\lockfile" del /F /Q "%PROFILE_DIR%\lockfile" >nul 2>&1

echo [4/4] جاري تشغيل شاشة الكاشير والموظف الآن...
echo ======================================================================
color 0A
echo   🎉 تم تثبيت وتحديث برنامج الموظف بنجاح تام إلى v5.7.0 PRO!
echo ======================================================================

set "EDGE_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "EDGE_EXE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"

set "TARGET_URL=http://192.168.10.27:5000/employee/login"

if defined EDGE_EXE (
    start "" "%EDGE_EXE%" --user-data-dir="%PROFILE_DIR%" --app="%TARGET_URL%" --window-size=1360,880 --no-first-run
) else (
    start "" "%TARGET_URL%"
)

ping 127.0.0.1 -n 3 >nul
exit
