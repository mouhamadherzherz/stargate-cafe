import re

with open('templates/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Replace class
old_card_class = 'class="item-card group relative rounded-3xl {% if item.track_stock and (item.stock_qty|default(0)|float) <= 0 %}bg-slate-950/90 border-2 border-rose-500/60 opacity-70{% else %}bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-amber-400/90 hover:shadow-2xl hover:shadow-amber-500/10 hover:-translate-y-1 active:scale-[0.98]{% endif %} transition-all duration-200 flex flex-col justify-between text-right shadow-lg overflow-hidden min-h-[220px] cursor-pointer select-none">'
new_card_class = 'class="item-card group relative rounded-3xl {% if not item.is_coffee_bean_linked and (item.stock_qty|default(0)|float) <= 0 %}bg-slate-950/90 border-2 border-rose-500/80 opacity-60 cursor-not-allowed{% else %}bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-amber-400/90 hover:shadow-2xl hover:shadow-amber-500/10 hover:-translate-y-1 active:scale-[0.98] cursor-pointer{% endif %} transition-all duration-200 flex flex-col justify-between text-right shadow-lg overflow-hidden min-h-[220px] select-none">'

if old_card_class in text:
    text = text.replace(old_card_class, new_card_class, 1)
    print("Replaced card class")
else:
    print("Warning: old_card_class not matched exactly")

# Replace badges
old_badges = """                        {% if item.track_stock %}
                            {% if (item.stock_qty|default(0)|float) <= 0 %}
                            <div class="absolute inset-0 z-20 bg-slate-950/75 backdrop-blur-[1px] flex flex-col items-center justify-center p-3 text-center pointer-events-none border-2 border-rose-500/80 rounded-3xl">
                                <span class="text-3xl mb-1">🚫</span>
                                <span class="bg-rose-600 text-white font-black text-[11px] px-2.5 py-1 rounded-xl shadow-lg border border-rose-400">
                                    غير مجرود / نفد المخزون
                                </span>
                                <span class="text-[9px] text-rose-200 mt-1 font-bold">الرصيد: 0 قطعة (البيع مقفل)</span>
                            </div>
                            <span class="absolute bottom-2.5 left-2.5 z-30 bg-rose-950/90 text-rose-300 font-bold text-[9px] px-2 py-0.5 rounded-lg border border-rose-600/70 shadow-md flex items-center gap-1">
                                <span>⚠️</span> نفد المخزون (0)
                            </span>
                            {% elif (item.stock_qty|default(0)|float) <= (item.low_stock_limit|default(5)|float) %}
                            <span class="absolute bottom-2.5 left-2.5 z-30 bg-amber-950/90 text-amber-300 font-bold text-[9px] px-2 py-0.5 rounded-lg border border-amber-600/70 shadow-md flex items-center gap-1 animate-pulse">
                                <span>⚡</span> متبقي {{ item.stock_qty|int }} فقط
                            </span>
                            {% else %}
                            <span class="absolute bottom-2.5 left-2.5 z-30 bg-slate-950/80 text-emerald-400 font-mono font-bold text-[9px] px-2 py-0.5 rounded-lg border border-slate-700 shadow-sm flex items-center gap-1">
                                <span>📦</span> متوفر: {{ item.stock_qty|int }}
                            </span>
                            {% endif %}
                        {% endif %}"""

new_badges = """                        {% if not item.is_coffee_bean_linked %}
                            {% if (item.stock_qty|default(0)|float) <= 0 %}
                            <div class="absolute inset-0 z-20 bg-slate-950/85 backdrop-blur-[2px] flex flex-col items-center justify-center p-3 text-center pointer-events-none border-2 border-rose-500/90 rounded-3xl">
                                <span class="text-3xl mb-1 animate-bounce">🚫</span>
                                <span class="bg-rose-600 text-white font-black text-xs px-3 py-1 rounded-xl shadow-xl border border-rose-400">
                                    غير مجرود / نفد المخزون
                                </span>
                                <span class="text-[10px] text-rose-200 mt-1 font-bold">الرصيد: 0 قطعة (البيع مقفل تماماً)</span>
                            </div>
                            <span class="absolute bottom-2.5 left-2.5 z-30 bg-rose-950 text-rose-300 font-bold text-[9px] px-2 py-0.5 rounded-lg border border-rose-600 shadow-md flex items-center gap-1">
                                <span>⚠️</span> نفد المخزون (0)
                            </span>
                            {% elif (item.stock_qty|default(0)|float) <= (item.low_stock_limit|default(5)|float) %}
                            <span class="absolute bottom-2.5 left-2.5 z-30 bg-amber-950/90 text-amber-300 font-bold text-[9px] px-2 py-0.5 rounded-lg border border-amber-600/70 shadow-md flex items-center gap-1 animate-pulse">
                                <span>⚡</span> متبقي {{ item.stock_qty|int }} فقط
                            </span>
                            {% else %}
                            <span class="absolute bottom-2.5 left-2.5 z-30 bg-slate-950/80 text-emerald-400 font-mono font-bold text-[9px] px-2 py-0.5 rounded-lg border border-slate-700 shadow-sm flex items-center gap-1">
                                <span>📦</span> متوفر: {{ item.stock_qty|int }}
                            </span>
                            {% endif %}
                        {% endif %}"""

if old_badges in text:
    text = text.replace(old_badges, new_badges, 1)
    print("Replaced badges")
else:
    print("Warning: old_badges not matched exactly")

# Update handleProductCardClick logic
old_click_guard = """        // 🛑 STRICT OUT-OF-STOCK GUARD (منع طلب أي منتج لا يوجد به مخزون وتنبيه الكاشير)
        if (type === 'cafe' && !isCoffeeLinked && trackStock && stockQty <= 0) {
            playBeep(250, 0.3);
            showOutOfStockModal(name, `رصيد هذا الصنف في المخزون حالياً هو (0). النظام مقفل ويمنع إضافة أي صنف نافد من المحل لحماية الحسابات.`);
            return;
        }

        // Check if item already in cart and adding another one would exceed stock
        const existingInCart = cart.find(i => (i.item_id && parseInt(i.item_id) === parseInt(id)) || (i.name === name && i.item_type === type));
        if (type === 'cafe' && !isCoffeeLinked && trackStock && existingInCart && existingInCart.quantity >= stockQty) {
            playBeep(250, 0.3);
            showOutOfStockModal(name, `لقد أضفت كافة الكمية المتوفرة في المخزون (${stockQty} قطعة). لا يمكن إضافة كمية إضافية لعدم توفر مخزون كافٍ.`);
            return;
        }"""

new_click_guard = """        // 🛑 STRICT OUT-OF-STOCK GUARD (منع طلب أي منتج لا يوجد به مخزون أو غير مجرود نهائياً)
        if (type === 'cafe' && !isCoffeeLinked && stockQty <= 0) {
            playBeep(250, 0.3);
            showOutOfStockModal(name, `رصيد هذا الصنف في المخزون حالياً هو (0) أو غير مجرود بالمحل! النظام مقفل ويمنع إضافة أي صنف غير متوفر حمايةً للمخزون ومنعاً للتلاعب.`);
            return;
        }

        // Check if item already in cart and adding another one would exceed stock
        const existingInCart = cart.find(i => (i.item_id && parseInt(i.item_id) === parseInt(id)) || (i.name === name && i.item_type === type));
        if (type === 'cafe' && !isCoffeeLinked && existingInCart && existingInCart.quantity >= stockQty) {
            playBeep(250, 0.3);
            showOutOfStockModal(name, `لقد أضفت كافة الكمية المتوفرة في المخزون (${stockQty} قطعة). لا يمكن إضافة كمية إضافية لعدم توفر مخزون كافٍ.`);
            return;
        }"""

if old_click_guard in text:
    text = text.replace(old_click_guard, new_click_guard, 1)
    print("Replaced click guard")
else:
    print("Warning: old_click_guard not matched exactly")

# Update cart quantity delta check
old_delta = "if (delta > 0 && it.track_stock && !it.is_coffee_linked && it.stock_qty !== undefined && it.stock_qty !== null) {"
new_delta = "if (delta > 0 && it.item_type === 'cafe' && !it.is_coffee_linked && it.stock_qty !== undefined && it.stock_qty !== null) {"
if old_delta in text:
    text = text.replace(old_delta, new_delta, 1)
    print("Replaced delta check")

with open('templates/index.html', 'w', encoding='utf-8') as f:
    f.write(text)

print("Finished script execution.")
